package com.example.evoting

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.evoting.R

class InputEmail : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_input_email)

        val emailEditText = findViewById<EditText>(R.id.etEmail)
        val continueButton = findViewById<Button>(R.id.btNext)

        continueButton.setOnClickListener {
            val email = emailEditText.text.toString()
            if (email.isNotEmpty()) {
                Toast.makeText(this, "Kode berhasil dikirim", Toast.LENGTH_SHORT).show()
                val intent = Intent(this, PageOtp::class.java)
                startActivity(intent)
            } else {
                Toast.makeText(this, "Please enter your email", Toast.LENGTH_SHORT).show()
            }
        }
    }
}
