package com.example.evoting

import android.content.Intent
import android.os.Bundle
import android.text.InputType
import android.view.MotionEvent
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.evoting.R

class PageRegister : AppCompatActivity() {
    private var isPasswordVisible = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_page_register)


        val editUsername: EditText = findViewById(R.id.etUsername)
        val editEmail: EditText = findViewById(R.id.etEmail)
        val editPassword: EditText = findViewById(R.id.etPassword)
        val editPasswordConfirm: EditText = findViewById(R.id.etPasswordConfirm)
        val buttonRegister: Button = findViewById(R.id.btRegister)
        val buttonLogin: Button = findViewById(R.id.btLogin)


        // Tampilkan/Sembunyikan Kata Sandi
        editPassword.setOnTouchListener { _, event ->
            if (event.action == MotionEvent.ACTION_UP) {
                if (event.rawX >= (editPassword.right - editPassword.compoundDrawables[2].bounds.width())) {
                    isPasswordVisible = !isPasswordVisible
                    editPassword.inputType = if (isPasswordVisible) {
                        InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD or InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS
                    } else {
                        InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD or InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS
                    }
                    editPassword.setSelection(editPassword.text.length)
                    val drawable = if (isPasswordVisible) R.drawable.baseline_visibility_24 else R.drawable.baseline_visibility_off_24
                    editPassword.setCompoundDrawablesRelativeWithIntrinsicBounds(0, 0, drawable, 0)
                    true
                } else false
            } else false
        }

        editPasswordConfirm.setOnTouchListener { _, event ->
            if (event.action == MotionEvent.ACTION_UP) {
                if (event.rawX >= (editPasswordConfirm.right - editPasswordConfirm.compoundDrawables[2].bounds.width())) {
                    isPasswordVisible = !isPasswordVisible
                    editPasswordConfirm.inputType = if (isPasswordVisible) {
                        InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD or InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS
                    } else {
                        InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD or InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS
                    }
                    editPassword.setSelection(editPassword.text.length)
                    val drawable = if (isPasswordVisible) R.drawable.baseline_visibility_24 else R.drawable.baseline_visibility_off_24
                    editPasswordConfirm.setCompoundDrawablesRelativeWithIntrinsicBounds(0, 0, drawable, 0)
                    true
                } else false
            } else false
        }


        // Tombol Daftar
        buttonRegister.setOnClickListener {
            val username = editUsername.text.toString()
            val email = editEmail.text.toString()
            val password = editPassword.text.toString()
            val passwordConfirm = editPasswordConfirm.text.toString()
            if (username.isNotEmpty() && email.isNotEmpty() && password.isNotEmpty() && passwordConfirm.isNotEmpty() ) {
                if (password != passwordConfirm) {Toast.makeText(this, "sandi tidak sama !", Toast.LENGTH_SHORT).show()
                } else{
                    Toast.makeText(this, "Daftar Berhasil!", Toast.LENGTH_SHORT).show()
                    val intent = Intent(this, PageOtp::class.java)
                    startActivity(intent)
                }
            } else{
                Toast.makeText(this, "Silakan isi semua field", Toast.LENGTH_SHORT).show()
            }
        }


        // login 2
        buttonLogin.setOnClickListener {
            val intent = Intent(this, PageLogin::class.java)
            startActivity(intent)
        }
    }
}

