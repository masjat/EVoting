package com.example.evoting


import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.evoting.R

class PageOtp : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_input_otp)


        val editTextOtp: EditText = findViewById(R.id.etOtp)
        val resendText: TextView = findViewById(R.id.rsOtp)
        val buttonNext: Button = findViewById(R.id.btNext)


        resendText.setOnClickListener {
            Toast.makeText(this, "Kode OTP dikirim ulang!", Toast.LENGTH_SHORT).show()
        }


        buttonNext.setOnClickListener {
            val otp = editTextOtp.text.toString()
            if (otp.isEmpty()) {
                Toast.makeText(this, "Masukkan Kode OTP terlebih dahulu!", Toast.LENGTH_SHORT).show()
            } else {
                Toast.makeText(this, "Kode OTP: $otp", Toast.LENGTH_SHORT).show()
            }
        }
    }
}
