package com.example.evoting

import android.content.Intent
import android.os.Bundle
import android.text.InputType
import android.view.MotionEvent
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.evoting.PageForgetPW
import com.example.evoting.PageOtp
import com.example.evoting.PageRegister
import com.example.evoting.R

class PageLogin : AppCompatActivity() {
    private var isPasswordVisible = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_page_login)


        val editUsername: EditText = findViewById(R.id.etEmail)
        val editPassword: EditText = findViewById(R.id.etPassword)
        val buttonLogin: Button = findViewById(R.id.btLogin)
        val buttonRegister: Button = findViewById(R.id.btRegister)
        val textForgotPassword: TextView = findViewById(R.id.txForgetPassword)


        editPassword.setOnTouchListener { _, event ->
            if (event.action == MotionEvent.ACTION_UP) {
                if (event.rawX >= (editPassword.right - editPassword.compoundDrawables[2].bounds.width())) {
                    isPasswordVisible = !isPasswordVisible
                    editPassword.inputType = if (isPasswordVisible) {
                        InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD or InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS
                    } else {
                        InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD or InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS
                    }
                    editPassword.setSelection(editPassword.text.length)
                    val drawable = if (isPasswordVisible) R.drawable.baseline_visibility_24 else R.drawable.baseline_visibility_off_24
                    editPassword.setCompoundDrawablesRelativeWithIntrinsicBounds(0, 0, drawable, 0)
                    true
                } else false
            } else false
        }


        textForgotPassword.setOnClickListener {
            val intent = Intent(this, PageForgetPW::class.java)
            startActivity(intent)
        }

        buttonLogin.setOnClickListener {
            val username = editUsername.text.toString()
            val password = editPassword.text.toString()
            if (username.isNotEmpty() && password.isNotEmpty()) {
                Toast.makeText(this, "Berhasil Masuk!", Toast.LENGTH_SHORT).show()
                val intent = Intent(this, PageOtp::class.java)
                startActivity(intent)
            } else {
                Toast.makeText(this, "Silakan isi semua field", Toast.LENGTH_SHORT).show()
            }
        }


        buttonRegister.setOnClickListener {
            val intent = Intent(this, PageRegister::class.java)
            startActivity(intent)
        }


    }
}
